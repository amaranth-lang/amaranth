from amaranth import *
from amaranth.lib import cdc, data


class RGBColor(data.Struct):
    r: 8
    g: 8
    b: 8


BLACK = RGBColor.const({"r": 0,   "g": 0,   "b": 0  })
WHITE = RGBColor.const({"r": 255, "g": 255, "b": 255})
RED   = RGBColor.const({"r": 255, "g": 0  , "b": 0  })
GREEN = RGBColor.const({"r": 0,   "g": 255, "b": 0  })


class Game(Elaboratable):
    def __init__(self, *, screen_width, screen_height):
        self.screen_width  = screen_width
        self.screen_height = screen_height

        self.tick   = Signal()

        self.btn_u  = Signal()
        self.btn_d  = Signal()
        self.btn_l  = Signal()
        self.btn_r  = Signal()
        self.btn_a  = Signal()
        self.btn_b  = Signal()

        self.beam_h = Signal(range(self.screen_width))
        self.beam_v = Signal(range(self.screen_height))
        self.color  = Signal(RGBColor)

    def elaborate(self, platform):
        raise NotImplementedError("Implement game logic here")


class CheckerboardTestPattern(Game):
    def elaborate(self, platform):
        m = Module()

        with m.If(self.beam_h[5] ^ self.beam_v[5]):
            m.d.comb += self.color.eq(WHITE)
        with m.Else():
            m.d.comb += self.color.eq(BLACK)

        return m


class MovableSquareGame(Game):
    SQUARE_SIZE = 20

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.square_x = Signal(range(self.screen_width))
        self.square_y = Signal(range(self.screen_height))

    def elaborate(self, platform):
        m = Module()

        with m.If((self.beam_h >= self.square_x) &
                  (self.beam_h <  self.square_x + self.SQUARE_SIZE) &
                  (self.beam_v >= self.square_y) &
                  (self.beam_v <  self.square_y + self.SQUARE_SIZE)):
            with m.If(self.btn_a):
                m.d.comb += self.color.eq(RED)
            with m.Elif(self.btn_b):
                m.d.comb += self.color.eq(GREEN)
            with m.Else():
                m.d.comb += self.color.eq(WHITE)
        with m.Else():
            m.d.comb += self.color.eq(BLACK)

        with m.If(self.tick):
            with m.If(self.btn_u):
                m.d.sync += self.square_y.eq(self.square_y - 1)
            with m.If(self.btn_d):
                m.d.sync += self.square_y.eq(self.square_y + 1)
            with m.If(self.btn_l):
                m.d.sync += self.square_x.eq(self.square_x - 1)
            with m.If(self.btn_r):
                m.d.sync += self.square_x.eq(self.square_x + 1)

        return m


class GameConsoleHardwareLCD(Elaboratable):
    SCREEN_H_VISIBLE = 480
    SCREEN_H_SYNC_AT = 485
    SCREEN_H_TOTAL   = 490

    SCREEN_V_VISIBLE = 270
    SCREEN_V_SYNC_AT = 275
    SCREEN_V_TOTAL   = 280

    def __init__(self, game_cls):
        self.game = game_cls(screen_width=self.SCREEN_H_VISIBLE,
                             screen_height=self.SCREEN_V_VISIBLE)

    def elaborate(self, platform):
        m = Module()

        tick    = Signal()
        beam_h  = Signal(range(self.SCREEN_H_TOTAL))
        beam_v  = Signal(range(self.SCREEN_V_TOTAL))
        beam_on = Signal()
        with m.If((beam_v == self.SCREEN_V_TOTAL - 1) &
                  (beam_h == self.SCREEN_H_TOTAL - 1)):
            m.d.sync += beam_on.eq(1)
            m.d.sync += beam_h.eq(0)
            m.d.sync += beam_v.eq(0)
            m.d.comb += tick.eq(1)
        with m.Elif(beam_h == self.SCREEN_H_TOTAL - 1):
            m.d.sync += beam_on.eq(beam_v < self.SCREEN_V_VISIBLE - 1)
            m.d.sync += beam_h.eq(0)
            m.d.sync += beam_v.eq(beam_v + 1)
        with m.Else():
            with m.If(beam_h == self.SCREEN_H_VISIBLE - 1):
                m.d.sync += beam_on.eq(0)
            m.d.sync += beam_h.eq(beam_h + 1)

        m.submodules.game = self.game
        m.d.comb += [
            self.game.tick.eq(tick),
            self.game.beam_h.eq(beam_h),
            self.game.beam_v.eq(beam_v),
        ]

        lcd = platform.request("lcd", xdr={"clk": 2})
        m.d.comb += [
            lcd.clk.o_clk.eq(ClockSignal()),
            lcd.clk.o0.eq(0),
            lcd.clk.o1.eq(1),
        ]
        m.d.sync += [
            lcd.hs.o.eq(beam_h == self.SCREEN_H_SYNC_AT),
            lcd.vs.o.eq(beam_v == self.SCREEN_V_SYNC_AT),
            lcd.de.o.eq(beam_on),
            lcd.r.o.eq(self.game.color.r[-len(lcd.r.o):]),
            lcd.g.o.eq(self.game.color.g[-len(lcd.g.o):]),
            lcd.b.o.eq(self.game.color.b[-len(lcd.b.o):]),
        ]

        gamepad = platform.request("gamepad")
        m.submodules += [
            cdc.FFSynchronizer(gamepad.u.i, self.game.btn_u),
            cdc.FFSynchronizer(gamepad.d.i, self.game.btn_d),
            cdc.FFSynchronizer(gamepad.l.i, self.game.btn_l),
            cdc.FFSynchronizer(gamepad.r.i, self.game.btn_r),
            cdc.FFSynchronizer(gamepad.a.i, self.game.btn_a),
            cdc.FFSynchronizer(gamepad.b.i, self.game.btn_b),
        ]

        return m


from amaranth.build import *
from amaranth_boards.tang_nano import TangNanoPlatform


class GowinTutorialPlatform(TangNanoPlatform):
    osc_frequency = 8_000_000
    resources = TangNanoPlatform.resources + [
        Resource("gamepad", 0,
            Subsignal("u", Pins("21", dir="i", invert=True)),
            Subsignal("d", Pins("22", dir="i", invert=True)),
            Subsignal("l", Pins("24", dir="i", invert=True)),
            Subsignal("r", Pins("19", dir="i", invert=True)),
            Subsignal("a", Pins("23", dir="i", invert=True)),
            Subsignal("b", Pins("15", dir="i", invert=True)),
            Attrs(IO_TYPE="LVCMOS33", PULL_MODE="UP")
        ),
    ]


def run_on_hardware():
    from amaranth_boards.tang_nano import TangNanoPlatform
    game_console = GameConsoleHardwareLCD(MovableSquareGame)
    platform = GowinTutorialPlatform()#toolchain="Gowin")
    platform.build(game_console, do_program=True)


run_on_hardware()
